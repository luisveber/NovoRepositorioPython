About
=====

License
-------

Refer to `LICENSE <https://github.com/kivymd/KivyMD/blob/master/LICENSE>`_.

.. literalinclude:: ../../LICENSE
   :language: none
   :emphasize-lines: 1,4
