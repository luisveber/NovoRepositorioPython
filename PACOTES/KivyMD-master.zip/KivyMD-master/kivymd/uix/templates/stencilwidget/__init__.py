from .stencilwidget import StencilWidget
